export default function PitoSidebarMode() {
  return (
    <div
      className="h-screen w-screen overflow-x-hidden"
      style={{
        fontFamily: "ui-monospace, monospace",
        fontSize: "16px",
        lineHeight: "1.4",
        backgroundColor: "#1a1b26",
        color: "#c0caf5",
      }}
    >
      <style>{`
        @keyframes shimmer-sweep {
          0% {
            background-position: -100% 0;
          }
          100% {
            background-position: 100% 0;
          }
        }
        
        @keyframes braille-spin {
          0% { content: "⠋"; }
          10% { content: "⠙"; }
          20% { content: "⠹"; }
          30% { content: "⠸"; }
          40% { content: "⠼"; }
          50% { content: "⠴"; }
          60% { content: "⠦"; }
          70% { content: "⠧"; }
          80% { content: "⠇"; }
          90% { content: "⠏"; }
          100% { content: "⠋"; }
        }

        .building-text {
          background: linear-gradient(
            90deg,
            #c0caf5 0%,
            #7dcfff 50%,
            #c0caf5 100%
          );
          background-size: 200% 100%;
          -webkit-background-clip: text;
          background-clip: text;
          -webkit-text-fill-color: transparent;
          animation: shimmer-sweep 2s infinite;
        }

        .braille-loader {
          display: inline-block;
          color: #7dcfff;
        }

        .post-indicator {
          display: inline-flex;
          gap: 0;
          background: linear-gradient(
            90deg,
            #565f89 0%,
            #7dcfff 25%,
            #565f89 50%,
            #565f89 100%
          );
          background-size: 200% 100%;
          -webkit-background-clip: text;
          background-clip: text;
          -webkit-text-fill-color: transparent;
          animation: shimmer-sweep 1.4s infinite;
        }
      `}</style>

      {/* MAIN: Chat shell with right padding for sidebar */}
      <main
        className="h-screen flex flex-col overflow-hidden"
        style={{ paddingRight: "480px" }}
      >
        {/* Scrollable message area */}
        <div className="flex-1 overflow-y-auto relative">
          {/* Top fade gradient */}
          <div
            className="absolute top-0 left-0 right-0 h-[24px] pointer-events-none z-10"
            style={{
              background: "linear-gradient(to bottom, #1a1b26, transparent)",
            }}
          />

          {/* Message content */}
          <div className="px-[80px] py-[24px] flex flex-col gap-[12px]">
            {/* Segment: USER message */}
            <Segment border="#ff9e64">
              <p>/channels overview</p>
            </Segment>

            {/* Segment: ASSISTANT prose */}
            <Segment>
              <p>Pulling stats for your 3 active channels over the last 7 days.</p>
            </Segment>

            {/* Segment: TOOL OUTPUT card */}
            <Segment border="#bb9af7" background="#24283b">
              <p style={{ color: "#565f89" }}># Channel rollup</p>
              <p className="mt-[16px]" style={{ color: "#7dcfff" }}>
                $ pito channels overview --period 7d
              </p>
              <pre className="mt-[16px] whitespace-pre">
                {`Channel             Subs       Views       Watched
@gmrdad82           1,240      48,310      612h
@gmrdad82-vlog        890      14,107      188h
@gmrdad82-shorts    3,712     192,840      241h`}
              </pre>
              <p
                className="mt-[8px] hover:underline cursor-pointer"
                style={{ color: "#565f89" }}
              >
                Click to expand
              </p>
            </Segment>

            {/* Segment: ASSISTANT prose paragraph */}
            <Segment>
              <p>
                Your <span style={{ color: "#7dcfff" }}>@gmrdad82-shorts</span>{" "}
                channel is your highest watch-time growth driver this week — 38%
                week-over-week. Consider doubling shorts cadence.
              </p>
            </Segment>

            {/* Segment: Status footer */}
            <Segment>
              <span style={{ color: "#565f89" }}>
                <span style={{ color: "#7dcfff" }}>▣</span> Build · Big Pickle ·
                1m 3s
              </span>
            </Segment>

            {/* Segment: In-progress */}
            <Segment border={null} background={null}>
              <span>
                <span className="braille-loader">⠋</span>
                {" "}
                <span className="building-text">Building</span>
                <span style={{ color: "#565f89" }}>…</span>
              </span>
            </Segment>
          </div>
        </div>

        {/* Chatbox - bar+gap+content pattern */}
        <div className="mx-[80px] mb-[8px] flex items-stretch gap-[6px]">
          {/* Bar: 4px purple */}
          <div
            style={{
              width: "4px",
              flexShrink: 0,
              backgroundColor: "#bb9af7",
            }}
          />
          {/* Content */}
          <div
            className="flex-1 flex flex-col"
            style={{ padding: "10px 16px 10px 12px", backgroundColor: "#1f2335" }}
          >
            {/* Line 1: Input area */}
            <div className="flex items-center">
              <span
                className="inline-block"
                style={{
                  width: "8px",
                  height: "16px",
                  backgroundColor: "#bb9af7",
                }}
              />
              <span className="ml-[8px]" style={{ color: "#565f89" }}>
                Ask anything…
              </span>
            </div>

            {/* Line 2: Filter context */}
            <div className="flex items-center gap-[4px]" style={{ color: "#565f89", marginTop: "10px" }}>
              <span>Channel:</span>
              <span style={{ color: "#7dcfff" }}>@gmrdad82</span>
              <span>·</span>
              <span>Period:</span>
              <span style={{ color: "#7dcfff" }}>7d</span>
            </div>
          </div>
        </div>

        {/* Status row */}
        <div
          className="mx-[80px] mb-[16px] flex justify-between items-center"
          style={{ color: "#565f89", paddingLeft: "10px" }}
        >
          {/* Post-command dots */}
          <div className="post-indicator">........</div>

          {/* Mini status */}
          <div style={{ whiteSpace: "nowrap", fontSize: "16px", lineHeight: "1.4" }}>
            <span style={{ color: "#9ece6a" }}>Connected</span>
            <span style={{ color: "#565f89", margin: "0 8px" }}>·</span>
            <span style={{ color: "#7dcfff" }}>3 notifications</span>
            <span style={{ color: "#565f89", margin: "0 8px" }}>·</span>
            <span style={{ color: "#e0af68", fontWeight: "bold" }}>ctrl+p</span>
            <span style={{ color: "#565f89", marginLeft: "4px" }}>commands</span>
          </div>
        </div>
      </main>

      {/* ASIDE: Fixed sidebar on right edge */}
      <aside
        style={{
          position: "fixed",
          right: 0,
          top: 0,
          bottom: 0,
          width: "480px",
          backgroundColor: "#1a1b26",
          borderLeft: "1px solid #292e42",
          zIndex: 10,
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
        }}
      >
        {/* Header — pinned, does NOT scroll */}
        <div
          style={{
            flex: "0 0 auto",
            padding: "16px",
            backgroundColor: "#1a1b26",
            borderBottom: "1px solid #292e42",
          }}
        >
          <div className="flex justify-between items-start">
            {/* Title block */}
            <div>
              <p style={{ color: "#7dcfff", fontWeight: "bold" }}>Hollow Knight</p>
              <p style={{ color: "#565f89" }}>Game · imported 2026-05-18</p>
            </div>
            {/* Esc hint */}
            <span style={{ color: "#565f89" }}>esc</span>
          </div>
        </div>

        {/* Body — scrollable */}
        <div
          style={{
            flex: "1 1 auto",
            overflowY: "auto",
            padding: "16px",
          }}
        >
          {/* Section: Overview */}
          <SectionLabel>Overview</SectionLabel>
          <div className="flex flex-col" style={{ gap: "2px" }}>
            <Row label="Genre" value="Metroidvania" />
            <Row label="Released" value="2017-02-24" />
            <Row label="Steam reviews" value="97% positive" />
            <Row label="Imported" value="8 days ago" />
          </div>

          {/* 24px gap */}
          <div style={{ height: "24px" }} />

          {/* Section: Channels covering this game */}
          <SectionLabel>Channels covering this game</SectionLabel>
          <div className="flex flex-col" style={{ gap: "2px" }}>
            <ChannelRow handle="@gmrdad82" count="3 videos" />
            <ChannelRow handle="@gmrdad82-vlog" count="1 video" />
            <ChannelRow handle="@gmrdad82-shorts" count="12 videos" />
          </div>

          {/* 24px gap */}
          <div style={{ height: "24px" }} />

          {/* Section: Top videos */}
          <SectionLabel>Top videos</SectionLabel>
          <div className="flex flex-col" style={{ gap: "2px" }}>
            <VideoRow date="2026-05-24" title="How to play Hollow Knight" views="12k views" />
            <VideoRow date="2026-05-21" title="Hollow Knight charms tier list" views="8k views" />
            <VideoRow date="2026-05-19" title="Speedrun guide" views="45k views" />
          </div>

          {/* 24px gap */}
          <div style={{ height: "24px" }} />

          {/* Section: Tags */}
          <SectionLabel>Tags</SectionLabel>
          <p>metroidvania, indie, souls-like, 2D platformer</p>

          {/* 24px gap */}
          <div style={{ height: "24px" }} />

          {/* Section: Recommendation */}
          <SectionLabel>Recommendation</SectionLabel>
          <p>
            Based on neighbor channel analysis, consider a Hollow Knight: Silksong preview video for @gmrdad82-shorts — audience overlap is 72%.
          </p>

          {/* 24px gap */}
          <div style={{ height: "24px" }} />

          {/* Section: Quick commands */}
          <SectionLabel>Quick commands</SectionLabel>
          <div className="flex flex-col" style={{ gap: "2px" }}>
            <CommandRow cmd="/import-game-videos Hollow Knight" />
            <CommandRow cmd="/channels-for-game Hollow Knight" />
            <CommandRow cmd="/export-game-data Hollow Knight" />
          </div>

          {/* Bottom padding */}
          <div style={{ height: "24px" }} />
        </div>
      </aside>
    </div>
  );
}

/* ============ LOCAL COMPONENTS ============ */

interface SegmentProps {
  border?: string | null;
  background?: string | null;
  children: React.ReactNode;
}

function Segment({ border = null, background = null, children }: SegmentProps) {
  return (
    <div className="flex items-stretch gap-[6px]">
      <div
        style={{
          width: "4px",
          flexShrink: 0,
          backgroundColor: border || "transparent",
        }}
      />
      <div
        className="flex-1"
        style={{
          padding: "10px 16px 10px 12px",
          backgroundColor: background || undefined,
        }}
      >
        {children}
      </div>
    </div>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p style={{ color: "#ff9e64", fontWeight: "bold", marginBottom: "4px" }}>
      {children}
    </p>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between" style={{ padding: "2px 0" }}>
      <span style={{ color: "#565f89" }}>{label}</span>
      <span>{value}</span>
    </div>
  );
}

function ChannelRow({ handle, count }: { handle: string; count: string }) {
  return (
    <div className="flex justify-between" style={{ padding: "2px 0" }}>
      <span style={{ color: "#7dcfff" }}>{handle}</span>
      <span>{count}</span>
    </div>
  );
}

function VideoRow({ date, title, views }: { date: string; title: string; views: string }) {
  return (
    <div className="flex justify-between" style={{ padding: "2px 0", gap: "16px" }}>
      <div className="flex-1 flex overflow-hidden" style={{ gap: "8px" }}>
        <span style={{ color: "#565f89", flexShrink: 0 }}>{date}</span>
        <span className="truncate">{title}</span>
      </div>
      <span style={{ color: "#7dcfff", flexShrink: 0 }}>{views}</span>
    </div>
  );
}

function CommandRow({ cmd }: { cmd: string }) {
  return (
    <div className="flex" style={{ padding: "2px 0", gap: "8px" }}>
      <span style={{ color: "#565f89" }}>·</span>
      <span style={{ color: "#7dcfff" }}>{cmd}</span>
    </div>
  );
}
