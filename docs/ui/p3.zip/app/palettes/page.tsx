export default function PalettesPage() {
  // Tokyo Night palette
  const colors = {
    bg: "#1a1b26",
    surface: "#1f2335",
    border: "#292e42",
    fg: "#c0caf5",
    dim: "#565f89",
    purple: "#bb9af7",
    orange: "#ff9e64",
    cyan: "#7dcfff",
  };

  // Slash palette commands
  const slashCommands = [
    { cmd: "/authenticate", desc: "Authenticate to access pito" },
    { cmd: "/channels", desc: "List your YouTube channels" },
    { cmd: "/videos", desc: "List videos for a channel" },
    { cmd: "/import", desc: "Import channel or video metadata" },
    { cmd: "/export", desc: "Export session transcript" },
    { cmd: "/help", desc: "Show help and command reference" },
    { cmd: "/clear", desc: "Clear the current session" },
    { cmd: "/new", desc: "Start a new session" },
  ];

  // Ctrl+P palette sections
  const suggestedSection = [
    { name: "New session", shortcut: "ctrl+x n" },
    { name: "Switch session", shortcut: "ctrl+x l" },
    { name: "Switch channel", shortcut: "tab" },
    { name: "Switch period", shortcut: "shift+tab" },
  ];

  const sessionSection = [
    { name: "Open editor", shortcut: "ctrl+x e" },
    { name: "Rename session", shortcut: "ctrl+r" },
    { name: "Jump to message", shortcut: "ctrl+x g" },
    { name: "Fork session", shortcut: "" },
    { name: "Compact session", shortcut: "ctrl+x c" },
    { name: "Share session", shortcut: "" },
    { name: "Export transcript", shortcut: "ctrl+x x" },
  ];

  const channelSection = [
    { name: "Refresh channels", shortcut: "" },
    { name: "Add channel", shortcut: "" },
    { name: "Remove channel", shortcut: "" },
    { name: "Toggle channel filter", shortcut: "" },
  ];

  const outputSection = [
    { name: "Copy last assistant message", shortcut: "ctrl+x y" },
    { name: "Copy session transcript", shortcut: "" },
    { name: "Show tool details", shortcut: "" },
    { name: "Toggle sidebar", shortcut: "ctrl+x b" },
    { name: "Show timestamps", shortcut: "" },
  ];

  // Render a section for Ctrl+P palette
  const renderSection = (
    label: string,
    items: { name: string; shortcut: string }[],
    selectedIndex: number | null = null
  ) => (
    <div>
      <div
        style={{
          color: colors.orange,
          fontWeight: "bold",
          marginBottom: "4px",
        }}
      >
        {label}
      </div>
      {items.map((item, i) => (
        <div
          key={i}
          style={{
            display: "flex",
            justifyContent: "space-between",
            padding: "2px 0",
            backgroundColor: selectedIndex === i ? colors.border : undefined,
            marginLeft: selectedIndex === i ? "-12px" : undefined,
            marginRight: selectedIndex === i ? "-16px" : undefined,
            paddingLeft: selectedIndex === i ? "12px" : undefined,
            paddingRight: selectedIndex === i ? "16px" : undefined,
          }}
        >
          <span style={{ color: colors.fg }}>{item.name}</span>
          {item.shortcut && (
            <span style={{ color: colors.dim }}>{item.shortcut}</span>
          )}
        </div>
      ))}
    </div>
  );

  return (
    <div
      style={{
        minHeight: "100vh",
        backgroundColor: colors.bg,
        fontFamily: "ui-monospace, monospace",
        fontSize: "16px",
        lineHeight: "1.4",
        color: colors.fg,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
      }}
    >
      {/* Content container */}
      <div style={{ width: "100%", maxWidth: "800px", padding: "16px" }}>
        {/* Page title */}
        <div style={{ color: colors.dim }}>
          pito — command palettes preview
        </div>

        {/* 24px gap */}
        <div style={{ height: "24px" }} />

        {/* Slash palette subheading */}
        <div style={{ color: colors.dim }}>
          Slash command palette · opens above chatbox when `/` is typed
        </div>

        {/* 12px gap */}
        <div style={{ height: "12px" }} />

        {/* Slash command palette */}
        <div style={{ display: "flex", gap: "6px" }}>
          {/* 4px purple bar */}
          <div
            style={{
              width: "4px",
              flexShrink: 0,
              backgroundColor: colors.purple,
            }}
          />
          {/* Content area */}
          <div
            style={{
              flex: 1,
              backgroundColor: colors.surface,
              padding: "10px 16px 10px 12px",
            }}
          >
            {/* Command list */}
            {slashCommands.map((cmd, i) => (
              <div
                key={i}
                style={{
                  display: "flex",
                  backgroundColor: i === 0 ? colors.border : undefined,
                  marginLeft: i === 0 ? "-12px" : undefined,
                  marginRight: i === 0 ? "-16px" : undefined,
                  paddingLeft: i === 0 ? "12px" : undefined,
                  paddingRight: i === 0 ? "16px" : undefined,
                }}
              >
                <span
                  style={{
                    color: colors.fg,
                    width: "160px",
                    flexShrink: 0,
                  }}
                >
                  {cmd.cmd}
                </span>
                <span style={{ color: colors.dim }}>{cmd.desc}</span>
              </div>
            ))}

            {/* 8px gap */}
            <div style={{ height: "8px" }} />

            {/* Divider */}
            <div
              style={{
                height: "1px",
                backgroundColor: colors.border,
              }}
            />

            {/* 8px gap */}
            <div style={{ height: "8px" }} />

            {/* Input echo line */}
            <div>
              <span
                style={{
                  backgroundColor: colors.purple,
                  color: colors.bg,
                }}
              >
                /
              </span>
            </div>
          </div>
        </div>

        {/* 48px gap */}
        <div style={{ height: "48px" }} />

        {/* Ctrl+P palette subheading */}
        <div style={{ color: colors.dim }}>
          Ctrl+P command palette · centered modal overlay
        </div>

        {/* 12px gap */}
        <div style={{ height: "12px" }} />

        {/* Ctrl+P modal */}
        <div style={{ display: "flex", justifyContent: "center" }}>
          <div
            style={{
              width: "600px",
              backgroundColor: colors.surface,
              border: `1px solid ${colors.border}`,
              padding: "16px",
            }}
          >
            {/* Title row */}
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <span style={{ color: colors.fg, fontWeight: "bold" }}>
                Commands
              </span>
              <span style={{ color: colors.dim }}>esc</span>
            </div>

            {/* 12px gap */}
            <div style={{ height: "12px" }} />

            {/* Search input */}
            <div
              style={{
                borderBottom: `1px solid ${colors.border}`,
                padding: "4px 0",
              }}
            >
              <span
                style={{
                  backgroundColor: colors.purple,
                  color: colors.bg,
                }}
              >
                S
              </span>
              <span style={{ color: colors.dim }}>earch</span>
            </div>

            {/* 16px gap */}
            <div style={{ height: "16px" }} />

            {/* Suggested section */}
            {renderSection("Suggested", suggestedSection, 0)}

            {/* 12px gap */}
            <div style={{ height: "12px" }} />

            {/* Session section */}
            {renderSection("Session", sessionSection)}

            {/* 12px gap */}
            <div style={{ height: "12px" }} />

            {/* Channel section */}
            {renderSection("Channel", channelSection)}

            {/* 12px gap */}
            <div style={{ height: "12px" }} />

            {/* Output section */}
            {renderSection("Output", outputSection)}
          </div>
        </div>

        {/* 48px gap at bottom */}
        <div style={{ height: "48px" }} />
      </div>
    </div>
  );
}
