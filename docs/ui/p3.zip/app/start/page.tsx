export default function PitoStartScreen() {
  return (
    <div
      className="h-screen w-screen flex flex-col relative"
      style={{
        fontFamily: "ui-monospace, monospace",
        fontSize: "16px",
        lineHeight: "1.4",
        backgroundColor: "#1a1b26",
        color: "#c0caf5",
      }}
    >
      {/* Logo + Chatbox group: chatbox center anchored at 50vh */}
      <div
        style={{
          position: "absolute",
          top: "50vh",
          left: "50%",
          transform: "translate(-50%, -50%)",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        {/* ASCII logo */}
        <pre style={{ fontSize: '18px', lineHeight: '1', margin: 0, whiteSpace: 'pre', fontFamily: 'ui-monospace, monospace', textAlign: 'center' }}>
<span style={{ color: '#5170ff' }}>██████</span><span style={{ color: '#565f89' }}>╗ </span><span style={{ color: '#5170ff' }}>██</span><span style={{ color: '#565f89' }}>╗</span><span style={{ color: '#5170ff' }}>████████</span><span style={{ color: '#565f89' }}>╗ </span><span style={{ color: '#5170ff' }}>██████</span><span style={{ color: '#565f89' }}>╗ </span>{'\n'}
<span style={{ color: '#5170ff' }}>██</span><span style={{ color: '#565f89' }}>╔══</span><span style={{ color: '#5170ff' }}>██</span><span style={{ color: '#565f89' }}>╗</span><span style={{ color: '#5170ff' }}>██</span><span style={{ color: '#565f89' }}>║╚══</span><span style={{ color: '#5170ff' }}>██</span><span style={{ color: '#565f89' }}>╔══╝</span><span style={{ color: '#5170ff' }}>██</span><span style={{ color: '#565f89' }}>╔═══</span><span style={{ color: '#5170ff' }}>██</span><span style={{ color: '#565f89' }}>╗</span>{'\n'}
<span style={{ color: '#5170ff' }}>██████</span><span style={{ color: '#565f89' }}>╔╝</span><span style={{ color: '#5170ff' }}>██</span><span style={{ color: '#565f89' }}>║   </span><span style={{ color: '#5170ff' }}>██</span><span style={{ color: '#565f89' }}>║   </span><span style={{ color: '#5170ff' }}>██</span><span style={{ color: '#565f89' }}>║   </span><span style={{ color: '#5170ff' }}>██</span><span style={{ color: '#565f89' }}>║</span>{'\n'}
<span style={{ color: '#5170ff' }}>██</span><span style={{ color: '#565f89' }}>╔═══╝ </span><span style={{ color: '#5170ff' }}>██</span><span style={{ color: '#565f89' }}>║   </span><span style={{ color: '#5170ff' }}>██</span><span style={{ color: '#565f89' }}>║   </span><span style={{ color: '#5170ff' }}>██</span><span style={{ color: '#565f89' }}>║   </span><span style={{ color: '#5170ff' }}>██</span><span style={{ color: '#565f89' }}>║</span>{'\n'}
<span style={{ color: '#5170ff' }}>██</span><span style={{ color: '#565f89' }}>║     </span><span style={{ color: '#5170ff' }}>██</span><span style={{ color: '#565f89' }}>║   </span><span style={{ color: '#5170ff' }}>██</span><span style={{ color: '#565f89' }}>║   ╚</span><span style={{ color: '#5170ff' }}>██████</span><span style={{ color: '#565f89' }}>╔╝</span>{'\n'}
<span style={{ color: '#565f89' }}>╚═╝     ╚═╝   ╚═╝    ╚═════╝ </span>
        </pre>

        {/* 32px gap */}
        <div style={{ height: "32px" }} />

        {/* Chatbox container — 75vw capped at 600px */}
        <div style={{ width: "75vw", maxWidth: "600px" }}>
          {/* Chatbox - P1.5 bar+gap+content pattern */}
          <div className="flex items-stretch gap-[6px] mb-[8px]">
            {/* Bar: 4px purple */}
            <div
              style={{
                width: "4px",
                flexShrink: 0,
                backgroundColor: "#bb9af7",
              }}
            />
            {/* Content - single line */}
            <div
              className="flex-1 flex items-center"
              style={{ padding: "10px 16px 10px 12px", backgroundColor: "#1f2335" }}
            >
              {/* Inverted-character cursor: / rendered as highlighted char */}
              <span
                style={{
                  backgroundColor: "#bb9af7",
                  color: "#1a1b26",
                  display: "inline",
                }}
              >/</span>
              {/* Remainder of placeholder in dim */}
              <span style={{ color: "#565f89" }}>
                {/* NOT-AUTHENTICATED state */}
                authenticate 123456
                {/* AUTHENTICATED state (commented out):
                List top videos
                */}
              </span>
            </div>
          </div>

          {/* Mini status row - right-aligned */}
          <div
            className="flex justify-end"
            style={{ color: "#565f89", paddingLeft: "10px" }}
          >
            <div
              style={{
                whiteSpace: "nowrap",
                fontSize: "16px",
                lineHeight: "1.4",
              }}
            >
              {/* NOT-AUTHENTICATED state */}
              <span style={{ color: "#f7768e" }}>Not authenticated</span>
              <span style={{ color: "#565f89", margin: "0 4px" }}>·</span>
              <span style={{ color: "#e0af68", fontWeight: "bold" }}>ctrl+p</span>
              <span style={{ color: "#565f89", marginLeft: "4px" }}>commands</span>
              {/* AUTHENTICATED state (commented out):
              <span style={{ color: "#9ece6a" }}>Authenticated</span>
              <span style={{ color: "#565f89", margin: "0 4px" }}>·</span>
              <span style={{ color: "#e0af68", fontWeight: "bold" }}>ctrl+p</span>
              <span style={{ color: "#565f89", marginLeft: "4px" }}>commands</span>
              */}
            </div>
          </div>
        </div>
      </div>

      {/* Tip — positioned at ~73vh, vertically centered in the space below the status row */}
      <div
        className="absolute w-full flex justify-center"
        style={{ top: "73vh" }}
      >
        <div
          style={{
            textAlign: "center",
            color: "#565f89",
            fontSize: "16px",
            lineHeight: "1.4",
          }}
        >
          <span style={{ color: "#e0af68" }}>●</span>
          <span style={{ color: "#e0af68", fontWeight: "bold", marginLeft: "4px" }}>Tip</span>
          <span style={{ margin: "0 4px" }}>—</span>
          <span>[placeholder for tip dictionary]</span>
        </div>
      </div>

      {/* Bottom-left: pitomd.com link */}
      <div
        className="absolute hover:underline"
        style={{
          bottom: "16px",
          left: "16px",
          color: "#565f89",
        }}
      >
        <a href="https://pitomd.com" target="_blank" rel="noopener noreferrer" style={{ color: "inherit", textDecoration: "none" }}>
          pitomd.com
        </a>
      </div>

      {/* Bottom-right: version */}
      <div
        className="absolute"
        style={{
          bottom: "16px",
          right: "16px",
          color: "#565f89",
        }}
      >
        0.1.0
      </div>
    </div>
  );
}
